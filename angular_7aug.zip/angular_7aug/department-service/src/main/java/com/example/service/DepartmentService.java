package com.example.service;

import com.example.model.Department;

public interface DepartmentService {
	
	Department findDepartmentByName(String departmentName);

}
