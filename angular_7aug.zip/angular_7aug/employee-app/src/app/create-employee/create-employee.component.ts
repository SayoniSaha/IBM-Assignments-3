import { Component } from '@angular/core';
import { Employee } from '../employee';
import { EmployeeService } from '../employee.service';
import { Router } from '@angular/router';
// import { Department } from '../department';
// import { DepartmentService } from '../department.service';

@Component({
  selector: 'app-create-employee',
  templateUrl: './create-employee.component.html',
  styleUrls: ['./create-employee.component.css']
})
export class CreateEmployeeComponent {
  // department: Department = new Department();
  employee: Employee = new Employee();

  constructor(
    private employeeService: EmployeeService,
    // private departmentService: DepartmentService,
    private router: Router
  ) { }

  // saveDepartment() {
  //   this.departmentService.createDepartment(this.department).subscribe(
  //     (departmentData) => {
  //       console.log('Department saved:', departmentData);
  //       this.saveEmployee();
  //     },
  //     (error) => console.log('Error saving department:', error)
  //   );
  // }

  saveEmployee() {
    this.employeeService.createEmployee(this.employee).subscribe(
      (employeeData) => {
        console.log('Employee saved:', employeeData);
        this.goToEmployeeList();
      },
      (error) => console.log('Error saving employee:', error)
    );
  }

  goToEmployeeList() {
    this.router.navigate(['/employees']);
  }

  onSubmit() {
    console.log(this.employee);
    // this.saveDepartment();
    this.saveEmployee();
  }
}
