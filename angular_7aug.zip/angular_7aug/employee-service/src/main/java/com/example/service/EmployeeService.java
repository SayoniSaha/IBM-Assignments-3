package com.example.service;

import com.example.model.EmployeeEntity;

public interface EmployeeService {
	
	EmployeeEntity createEmployee(EmployeeEntity employee);
}
