package com.example.controller;

import java.util.List;

import org.springframework.core.env.Environment;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.dto.DepartmentFeignClient;
import com.example.model.EmployeeEntity;
import com.example.repo.EmployeeRepository;
import com.example.service.EmployeeService;
import com.example.ui.DepartmentDto;

import lombok.AllArgsConstructor;

@CrossOrigin(origins = "http://localhost:4200")
@RestController
@RequestMapping("/employees")
@AllArgsConstructor
public class EmployeeController {

	private final EmployeeService employeeService;
    private final EmployeeRepository employeeRepository;
    private final Environment environment;
    private final DepartmentFeignClient departmentFeignClient;

	@GetMapping("/status")
	public ResponseEntity<?> status() {
		return ResponseEntity.ok("employee-service is up and runuing on port: " + environment.getProperty("local.server.port"));
	}
	
	@GetMapping("/list")
	public List<EmployeeEntity> getAllEmployees() {
		return employeeRepository.findAll();
	}

	@PostMapping("/add/{departmentName}")
    public ResponseEntity<?> createEmployee(@RequestBody EmployeeEntity employee, @PathVariable("departmentName") String departmentName) {
        DepartmentDto dto = departmentFeignClient.getDepartmentByName(departmentName);

        employee.setDepartmentName(dto.getDepartmentName());
        return ResponseEntity.status(HttpStatus.CREATED).body(employeeService.createEmployee(employee));
    }

}
