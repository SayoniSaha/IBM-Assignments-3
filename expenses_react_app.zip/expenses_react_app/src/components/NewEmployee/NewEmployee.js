import React from 'react';

import EmployeeForm from './EmployeeForm';
import './NewEmployee.css';

const NewEmployee = () => {
  return (
    <div className='new-employee'>
      <EmployeeForm />
    </div>
  );
};

export default NewEmployee;