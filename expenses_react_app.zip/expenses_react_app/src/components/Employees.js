import './Employees.css'
function Employees()
{
    return (
        <div>
          <h2>Employees Component</h2>
          
        </div>
      );
     
}
export default Employees;